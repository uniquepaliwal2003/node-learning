# AppStack – Admin & Dashboard Template

Thanks for buying. Navigate to `docs/docs-installation.html` to get started.
