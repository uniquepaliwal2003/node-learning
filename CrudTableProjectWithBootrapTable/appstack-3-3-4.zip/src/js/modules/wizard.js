import "smartwizard/dist/js/jquery.smartWizard.min.js";
