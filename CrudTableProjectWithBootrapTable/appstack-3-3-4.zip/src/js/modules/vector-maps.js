// Usage: https://github.com/themustafaomar/jsvectormap
import "jsvectormap"
import "./vector-maps/world.js"
import "./vector-maps/us-aea-en.js"