import Quill from "quill/dist/quill.js";

window.Quill = Quill;